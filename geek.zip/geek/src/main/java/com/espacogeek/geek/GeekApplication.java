package com.espacogeek.geek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeekApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeekApplication.class, args);
	}

}
